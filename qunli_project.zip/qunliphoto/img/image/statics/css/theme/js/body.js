// JavaScript Document
jQuery(".fullSlide").hover(function() {
    jQuery(this).find("http://www.qunliphoto.com/statics/css/theme/js/.prev,.next").stop(true, true).fadeTo("show", 0.5)
},
function() {
    jQuery(this).find("http://www.qunliphoto.com/statics/css/theme/js/.prev,.next").fadeOut()
});
jQuery(".fullSlide").slide({
    titCell: ".hd ul",
    mainCell: ".bd ul",
    effect: "fold", 
    autoPlay: true,
    autoPage: true,
    trigger: "click",
    startFun: function(i) {
        var curLi = jQuery(".fullSlide .bd li").eq(i);
        if ( !! curLi.attr("_src")) {
            curLi.css("background-image", curLi.attr("_src")).removeAttr("_src")
        }
    }
});

// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});


$(function(){
	$(".zhaopin_container ul li ul li").mouseenter(function(event) {
		var itemnum=parseInt($(this).attr('itemnum'));
		var containernum=(itemnum%4==0)?itemnum:(4-itemnum%4+itemnum);
		$(this).closest('ul').find('.container_'+containernum).html( $(this).find('.demand').html());
		// $(this).closest('ul').find('.container_'+containernum).css('display',"block");
		$(".demand_container").not($(this).closest('ul').find('.container_'+containernum)).hide(300);
		$(this).closest('ul').find('.container_'+containernum).hide(0).show(300);
	});
	
	var index_activit = $(".index_activit").find("a").children("img");
	index_activit.hover(function () {
		index_activit.not($(this)).stop().animate({ opacity: 0.3 }, 500);
	}, function () {
		index_activit.not($(this)).stop().animate({ opacity: 1 }, 500);
	});
	
	$(".guanggao2 li a").hover(function(){
		$(this).find("big img").stop().animate({opacity:0.5},800);
		},function(){
		$(this).find("big img").stop().animate({opacity:1},800);
	});
})

$(function(){
	float();
	$(window).resize(function(){float();});
	$(".gotop").click(function(){
		$("body,html").stop().animate({scrollTop:0},500);
		return false;
	});
	
	setInterval(function(){
		$(".footer .p1 span").css({"left":"-1000000px"});
		setTimeout(function(){
			$(".footer .p1 span").css({"left":"0px"});
		},1000);
	},2000);
	
});
function float(){
	if( $(".web_float").length>0 )
	{
		if( $(window).width()>1280 )
		{
			$(".web_float").show();
			$(window).scroll(function(){
				$(".web_float").each(function(){
					if( parseInt($(document).scrollTop())>=745 )
					{
						$(this).stop().animate({top:$(document).scrollTop()+($(window).height()-($(this).height()+12))/2},500);
					}
					else if(  parseInt($(document).scrollTop())<=745  )
					{
						$(this).stop().animate({top:"745px"},500);
					};
				});
			});
		}
		else
		{
			$(".web_float").hide();
		}
	};
}

// JavaScript Document
$(function() {
    var msg_inter_handle, msg_timeout_handle;
    //提交信息表单提交出发事件
    $('#myform,#myform2,').submit(function(eve) {
console.log($(eve.target));
        eve.preventDefault(); //取消默认提交事件
        clearInterval(msg_inter_handle); //取消倒计时.重新开始
        clearInterval(msg_timeout_handle); //取消倒计时.重新开始
        $.ajax({
            url: $(this).attr('action'),
            data: $(this).serialize() + '&dosubmit=',
            type: 'POST',
            beforeSend: function() {
                var i = 5;
                //console.log(this);
				
                if ($(eve.target).find('#zx_name').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入姓名<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入姓名<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
                if ($(eve.target).find('#zx_tel').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入手机号<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入手机号<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
				if ($(eve.target).find('#youhui_name').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入姓名<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入姓名<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
                if ($(eve.target).find('#youhui_tel').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入手机号<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入手机号<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
				if ($(eve.target).find('#tg_name').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入姓名<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入姓名<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
                if ($(eve.target).find('#tg_tel').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入手机号<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入手机号<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
				if ($(eve.target).find('#hd_name').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入姓名<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入姓名<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
                if ($(eve.target).find('#hd_tel').val() == '') {
                    $(".msg_tanchuang_show2").html('请输入手机号<br>' + i + '秒后自动关闭!');
                    msg_inter_handle = setInterval(function() {
                        if (i <= 1) {
                            i = 5;
                            clearInterval(msg_inter_handle);
                            $(".opacaity_0").hide();
                            return false;
                        }
                        $(".msg_tanchuang_show2").html('请输入手机号<br>' + (--i) + '秒后自动关闭!');
                    }, 1000);
                    $(".baoming_group").hide(); //隐藏正常提示
                    $(".msg_tanchuang_show2").show(); //显示错误提示
                    $(".opacaity_0").show(); //显示弹窗顶层框架div
                    return false;
                }
            },
            success: function() {
                $(".baoming_group").hide(); //隐藏所有提示
                $("http://www.qunliphoto.com/statics/css/theme/js/.baoming_group.zero").show(); //提交成功div显示

                $(".msg_tanchuang_show2").hide(); //错误提示隐藏
                $(".opacaity_0").show(); //弹窗顶层div显示
                setTimeout('$(".opacaity_0").hide();', 5000); //5秒后隐藏弹窗顶层div
                $(eve.target).find('.formtext').val(''); //清空提交表单的input值
            }
        });
    });
    //弹窗关闭按钮被点击事件
    $(".hide_msg_container_clo").click(function() {
        clearInterval(msg_inter_handle);
        clearInterval(msg_timeout_handle);
        $(".opacaity_0").hide();
    });
});

$(document).ready(function() {
    $(".kezhao_list ul li .gue-item").mouseenter(function() {
        $(this).find('.gue-itmore').stop().animate({
            opacity: 1
        }, 300);
        $(this).find('.gue-ittitle').stop().animate({
            opacity: 1
        }, 300);
        // $(this).find('.gue-ittitle').stop().animate({ bottom: 0 }, 300);
        $(this).find('.bs-limit').stop().animate({
            'bottom': 0,
            'opacity': 1
        }, 300);
    });

    $(".kezhao_list ul li .gue-item").mouseleave(function() {
        $(this).find('.gue-itmore').stop().animate({
            opacity: 0
        }, 300);
        $(this).find('.gue-ittitle').stop().animate({
            opacity: 0
        }, 300);
        // $(this).find('.gue-ittitle').stop().animate({ bottom: -50 }, 300);
        $(this).find('.bs-limit').stop().animate({
            'bottom': -50,
            'opacity': 0
        }, 300);
    });

});

$(".SHowcaseconUL").hover(function () {
	$(this).find("i").stop().animate({ top: "-120" }, 500);
}, function () {
	$(this).find("i").stop().animate({ top: "-530" }, 500);
});

$(document).ready(function(){ 
	// 添加收藏 
	$(".shoucang_zd").click(function(){ 
		var ctrl = (navigator.userAgent.toLowerCase()).indexOf('mac') != -1 ? 'Command/Cmd': 'CTRL'; 
		if (document.all) { 
			window.external.addFavorite('../../../../index.htm'/*tpa=http://www.qunliphoto.com/*/, '成都群丽婚纱摄影'); 
		} else if (window.sidebar) { 
			window.sidebar.addPanel('成都群丽婚纱摄影', '../../../../index.htm'/*tpa=http://www.qunliphoto.com/*/, ""); 
		} else { 
			alert('当前浏览器不支持，您可以尝试通过快捷键' + ctrl + ' + D 把成都群丽网站加入到收藏夹'); 
		}	
			return false; 
	}); 
}); 

