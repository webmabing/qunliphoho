$(function(){
	
	//节点查找
	var el={};
	
	//弹窗后，绑定在window的resize事件上
	el.footerContactPhone=$('.footer-bar');
    var reSetBottomWidth=function(){
    	el.footerContactPhone.css('width',$(window).width()-$.plugins.scrollWidth+'px');
	};
	
	//
	$('.pub-dajax').click(function(){
		el.footerContactPhone.css('width',$(window).width()+'px');
		Dajax=new xqDialog();
		Dajax.open({scroll:'scroll',href:$(this).attr('href'),open:function(){
			$(window).bind('resize',reSetBottomWidth).trigger('resize');
		},close:function(){
			el.footerContactPhone.css('width','100%');
			$(window).unbind('resize',reSetBottomWidth);
		}});
	});
	
	
	
	
	
	
	
	
	
	
});