// JavaScript Document
$(document).ready(function(){

$("a").focus(function(){$(this).blur();});


 $(".nav_new ul li").hover(function(){
		$(this).find("dl").stop().animate({height:$(this).find("dd").size()*32},200);
		$(this).find("p a").addClass("hover1");
	},function(){
		$(this).find("dl").stop().animate({height:0},200);
		$(this).find("p a").removeClass("hover1");
});	

if($("#photo1 ul li").size()>0){
$("#photo1 ul").tabs("#photo1 > div", {effect: 'fade',loop:true,fadeOutSpeed:1000,fadeInSpeed:1000,rotate: true,event:'mouseover'}).slideshow({autoplay:false,interval: 4000});
}

$(".t_right li").hover(function(){

	$(this).find("big").stop().animate({width:"387px"},300);
		
	},function(){
	
	$(this).find("big").stop().animate({width:"0"},300);							
	
	})


$(".indexYp li").hover(function(){

	$(this).find("ins").stop().animate({bottom:"0"},400);
		
	},function(){
	
	$(this).find("ins").stop().animate({bottom:"-1000px"},400);							
	
	})	
})
$(window).scroll(function(){
	if ($(window).scrollTop()>130){
		$(".iloft-gift a").addClass("affix");
	}
	else
	{
		$(".iloft-gift a").removeClass("affix");
	}
});

